<?php

namespace Twig\Extensions;

class_exists('Twig_Extensions_Extension_Array');

if (\false) {
    class ArrayExtension extends \Twig_Extensions_Extension_Array
    {
    }
}
