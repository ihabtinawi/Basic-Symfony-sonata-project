<?php

namespace Twig\Extensions\TokenParser;

class_exists('Twig_Extensions_TokenParser_Trans');

if (\false) {
    class TransTokenParser extends \Twig_Extensions_TokenParser_Trans
    {
    }
}
