<?= "<?php\n" ?>

namespace <?= $namespace ?>;

use Sonata\AdminBundle\Controller\CRUDController;

class <?= $class_name ?> extends CRUDController
{

}
