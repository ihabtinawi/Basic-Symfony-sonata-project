<?php

/*
 * This file is part of the Sonata Project package.
 *
 * (c) Thomas Rabaix <thomas.rabaix@sonata-project.org>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Sonata\Doctrine\Bridge\Symfony\Bundle;

use Sonata\Doctrine\Bridge\Symfony\DependencyInjection\SonataDoctrineExtension;
use Symfony\Component\HttpKernel\Bundle\Bundle;

final class SonataDoctrineBundle extends Bundle
{
    public function getPath()
    {
        return __DIR__.'/..';
    }

    protected function getContainerExtensionClass()
    {
        return SonataDoctrineExtension::class;
    }
}
